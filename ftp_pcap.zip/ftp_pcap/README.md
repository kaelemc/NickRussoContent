# FTP/FTPS/SFTP/SCP/TFTP Packet Captures
Please enjoy these free packet captures to help you in your studies,
daily work, or general exploration.

# Pluralsight Course
These packet captures support my Pluralsight course titled
"Protocol Deep Dive: FTP and Its Variants", accessible here:
`https://www.pluralsight.com/courses/protocol-deep-dive-ftp-variants`

Please check out this course if you'd like to better understand
the context/applicability of these packet captures.

# Licensing
Please contact Nick Russo (njrusmc@gmail.com) with any questions.

Copyright 2020 Nicholas Russo. All rights reserved.
